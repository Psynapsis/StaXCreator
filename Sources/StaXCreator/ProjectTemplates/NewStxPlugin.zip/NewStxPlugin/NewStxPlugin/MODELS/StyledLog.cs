﻿namespace $safeprojectname$.Models;

public record StyledLog(string Text, LogType LogType);