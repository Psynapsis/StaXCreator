﻿namespace $safeprojectname$.Models;

public enum LogType
{
    None,
    Warning,
    Error,
    Info,
}