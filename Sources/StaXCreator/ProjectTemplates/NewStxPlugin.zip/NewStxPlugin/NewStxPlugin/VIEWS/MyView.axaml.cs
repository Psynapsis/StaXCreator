using Avalonia.Controls;

namespace $safeprojectname$.Views;

public partial class MyView : UserControl
{
    public MyView() => InitializeComponent();
}