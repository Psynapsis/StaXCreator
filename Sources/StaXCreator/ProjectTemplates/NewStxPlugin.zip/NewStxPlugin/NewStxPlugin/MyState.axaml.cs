using Avalonia.Markup.Xaml;
using FluentAvalonia.UI.Controls;
using StaX.Domain;
using $safeprojectname$.ViewModels;
using $safeprojectname$.Views;

namespace $safeprojectname$;

public partial class MyState : UiState
{
    public override string StateName { get; protected set; } = "$safeprojectname$";
    public override string ToolTip { get; protected set; } = "$safeprojectname$";
    public override Symbol? Icon { get; protected set; } = Symbol.Account;

    public MyState()
    {
        StateView = new MyView();
        StateViewModel = new MyViewModel();
    }

    public override void Initialize() => AvaloniaXamlLoader.Load(this);
}